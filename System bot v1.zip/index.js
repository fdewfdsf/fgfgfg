 const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.send('Hello Express app!')
});

app.listen(3000, () => {
  console.log('server started');
});

let prefix = "!"

let {Client, Message, MessageEmbed, Collection, MessageButton, Intents,MessageAttachment} = require("discord.js")
const { createCanvas, loadImage } = require('canvas');

let client = new Client({
  intents:32767
})
client.commands=new Collection()
client.slash=new Collection()
client.on("ready",()=>{
console.log(client.user.username+"\t is online")
  setInterval(() => {

    const activities = ['/help' , '/bot'];
    const random = activities[Math.floor(Math.random() * activities.length)]
    
    client.user.setActivity(`${random}`, {type: `WATCHING`});

    }, 1000 * 20)   
client.user.setPresence({
    status: "idle",
  });

setTimeout(() => {
  if (!client || !client.user) {
    console.log("Client Not Login, Process Kill")
    process.kill(1);
  } else {
    console.log("Client Login")
  }
}, 5 * 1000 * 60);
  
})


let fs = require("fs")

let sAr = []
fs.readdirSync('./SlashCommands').forEach((folder) => {
    const commandFiles = fs.readdirSync(`./SlashCommands/${folder}`).filter(file => file.endsWith('.js'));
    for (file of commandFiles) {
        let command = require(`./SlashCommands/${folder}/${file}`)
        if (command.name) {
            client.slash.set(command.name, command);
        sAr.push(command)
        }
  
      
    }
})
  
client.on("ready",()=>{
  client.application.commands.set(sAr)
})




client.on("interactionCreate", interaction =>{

if (!interaction.isCommand()) return;
if (!interaction.channel.guild) return;

const command = client.slash.get(interaction.commandName);

if (!command) return;

   command.run(client, interaction);
  
})
process.on("unhandledRejection", (reason, promise) => {
  console.log(reason)
})
process.on("uncaughtException", (err, origin) => {
  console.log(err)
})
process.on('uncaughtExceptionMonitor', (err, origin) => {
  console.log(err)
});
process.on('multipleResolves', (type, promise, reason) => {
  console.log(type , reason)
});

//=========================//

client.login("OTM1MTk2NzI2OTA0NjMxMzU4.GWcIy6.3n5wj5gxEs6F9eW2NgIGCJ7P9CjuFWCnerNA7U")

//=========================//
const db = require("pro.db");

client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const guildId = message.guild.id;
  const badWords = db.get(`bad_words_${guildId}`) || [];
  const content = message.content.toLowerCase();
  const member = message.member;

  if (member.permissions.has("ADMINISTRATOR")) {
    return;
  }

  for (const word of badWords) {
    if (content.includes(word)) {
      await message.delete();

      const embed = new MessageEmbed()
        .setColor("RED")
        .setDescription("Sending bad words and links is prohibited.");

      const sentMessage = await message.channel.send({ embeds: [embed] });

      setTimeout(async () => {
        await sentMessage.delete();
      }, 5000);

      return;
    }
  }
});
//=======================================================================auto-reply=====================================================================//
client.on("messageCreate", async (message) => {
  if (message.author.bot) return;

  const trigger = message.content;
  const response = db.get(`auto-reply_${message.guild.id}_${trigger}`);

  if (response) {
    message.reply(response);
  }
});
//=====================================================================================================================================================//
client.on("guildCreate", guild => {
  
  const ownerId = guild.ownerId
  const owner = guild.members.cache.get(ownerId)
  let newServser = client.channels.cache.find(c => c.id === '1246039394763407390')

  
const verificationLevels = {NONE: '0',LOW: '1',MEDIUM: '2',HIGH: '3',VERY_HIGH: '4'};
  
let on = guild.presences.cache.filter(e => e.status == 'online').size - 1 || 0
let idle = guild.presences.cache.filter(e => e.status == 'idle').size + 1 || 0
let dnd = guild.presences.cache.filter(e => e.status == 'dnd').size || 0
  
 
  const embed = new MessageEmbed()
   
.setAuthor(`${client.user.username}`, client.user.avatarURL({ dynamic: true }))

.setThumbnail(client.user.avatarURL({ dynamic: true }))
    
    .addField('> Name:', `\`${guild.name}\``, false)
    
    .addField('> Id:', `\`${guild.id}\``, false)
    
    .addField('> Creadted at:', `<t:${parseInt(guild.createdAt / 1000)}:R>`, false)
    
    .addField('> Owner:', `[${owner.user.tag}](https://discord.com/users/${owner.id})`, false)
    
    .addField(`> Members: ${guild.memberCount}`, `\`${Math.floor(on + idle + dnd)} Online\` | \`${guild.premiumSubscriptionCount} Boosts\``, false)
    
    .addField(`> Channels: ${guild.channels.cache.size}`, `\`${guild.channels.cache.filter(m => m.type === 'GUILD_TEXT').size} Text\` | \`${guild.channels.cache.filter(m => m.type === 'GUILD_VOICE').size} Voice\``, false)
    
    .addField(`> Others: `, `\`Verification Level: ${verificationLevels[guild.verificationLevel]}\``, false)
    
    .setColor(`GREEN`)
   
    newServser.send({ embeds: [embed] , content: `Join server: <@${client.user.id}>`}).catch((err) => {
   console.log(`i couldn't reply to the message: ` + err.message)
                        })
});

client.on("guildDelete", guild => {
  
  const ownerId = guild.ownerId
  const owner = guild.members.cache.get(ownerId)
  let newServser = client.channels.cache.find(c => c.id === '1246039394763407390')

  
const verificationLevels = {NONE: '0',LOW: '1',MEDIUM: '2',HIGH: '3',VERY_HIGH: '4'};
  
let on = guild.presences.cache.filter(e => e.status == 'online').size - 1 || 0
let idle = guild.presences.cache.filter(e => e.status == 'idle').size + 1 || 0
let dnd = guild.presences.cache.filter(e => e.status == 'dnd').size || 0
  
 
  const embed = new MessageEmbed()
   
.setAuthor(`${client.user.username}`, client.user.avatarURL({ dynamic: true }))

.setThumbnail(client.user.avatarURL({ dynamic: true }))
    
    .addField('> Name:', `\`${guild.name}\``, false)
    
    .addField('> Id:', `\`${guild.id}\``, false)
    
    .addField('> Creadted at:', `<t:${parseInt(guild.createdAt / 1000)}:R>`, false)
    
    .addField('> Owner:', `[${owner.user.tag}](https://discord.com/users/${owner.id})`, false)
    
    .addField(`> Members: ${guild.memberCount}`, `\`${Math.floor(on + idle + dnd)} Online\` | \`${guild.premiumSubscriptionCount} Boosts\``, false)
    
    .addField(`> Channels: ${guild.channels.cache.size}`, `\`${guild.channels.cache.filter(m => m.type === 'GUILD_TEXT').size} Text\` | \`${guild.channels.cache.filter(m => m.type === 'GUILD_VOICE').size} Voice\``, false)
    
    .addField(`> Others: `, `\`Verification Level: ${verificationLevels[guild.verificationLevel]}\``, false)
    
    .setColor(`GREEN`)
   
    newServser.send({ embeds: [embed] , content: `leave server: <@${client.user.id}>`}).catch((err) => {
   console.log(`i couldn't reply to the message: ` + err.message)
                        })
});
//=======================================================================Sug============================================================================//
client.on("messageCreate", async(message) => {
   if(message.author.bot) return;
   let channel = db.get(`Sug_${message.guild.id}`)
  if(channel == null) return;
  if(message.channel.id != channel) return;
  let line = db.get(`line_${message.guild.id}`)
  let color = db.get(`color_${message.guild.id}`)
  message.channel.send({embeds: [
    new MessageEmbed()
    .setTimestamp()
    .setAuthor({name : message.author.username , iconURL : message.author.displayAvatarURL({ dynamic: true })})
    .setFooter({text : message.author.username , iconURL : message.author.displayAvatarURL({ dynamic: true })})
    .setThumbnail(message.author.displayAvatarURL({dynamic: true}))
    .setDescription(`
    **New Suggestions** 
**
${message.content}
**
`)
    .setColor(color ? color : "CYAN")
  ]}).then(async(m) => {
    m.react("✅")
    m.react("❌")
  })
  message.delete()
})
//=======================================================================Sug============================================================================//
client.on("messageCreate", async (message) => {
  try {
    if (message.author.bot) return;

    let channel = db.get(`Fed_${message.guild.id}`);
    if (channel == null) return;
    if (message.channel.id != channel) return;

    let color = db.get(`color_${message.guild.id}`);

    await message.delete();

    const embed = new MessageEmbed()
      .setTimestamp()
      .setAuthor({ name: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setFooter({ text: message.author.username, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
      .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
      .setDescription(`
        **
        > ${message.content} 💙
        **
      `)
      .setColor("BLUE");

   const row = new MessageActionRow()
    .addComponents(
        new MessageButton()
            .setCustomId('1_star')
            .setLabel('⭐')
            .setStyle('PRIMARY'),
        new MessageButton()
            .setCustomId('2_stars')
            .setLabel('⭐⭐')
            .setStyle('PRIMARY'),
        new MessageButton()
            .setCustomId('3_stars')
            .setLabel('⭐⭐⭐')
            .setStyle('PRIMARY'),
        new MessageButton()
            .setCustomId('4_stars')
            .setLabel('⭐⭐⭐⭐')
            .setStyle('PRIMARY'),
        new MessageButton()
            .setCustomId('5_stars')
            .setLabel('⭐⭐⭐⭐⭐')
            .setStyle('PRIMARY')
    );
    const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });
    const filter = (interaction) => interaction.isButton();
    const collector = sentMessage.createMessageComponentCollector({ filter, max: 1, time: 60000 });
    collector.on('collect', async (interaction) => {
      const chosenStar = interaction.customId;
      row.components.forEach(component => component.setDisabled(true));
      row.components.find(component => component.customId === chosenStar).setDisabled(false);
      await interaction.update({ components: [row] });
      collector.stop();
    });
    collector.on('end', (collected, reason) => {
      if (reason === 'time') {
        console.log('لم يتم تقديم الرأي في الوقت المحدد.');
      }
    });
  } catch (error) {
    console.error('حدث خطأ:', error);
  }
});
//=======================================================================welcome========================================================================//
const path = require('path'); 

client.on('guildMemberAdd', async (member) => {
    try {
        let channelID = db.get(`welcome_${member.guild.id}`);
        if (!channelID) return;

        const canvas = createCanvas(3840, 2160);
        const ctx = canvas.getContext('2d');

        const backgroundPath = path.join(__dirname, 'Images', 'welcome.png');
        const background = await loadImage(backgroundPath);
        ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

        const avatarSize = 1220;
        const avatar = await loadImage(member.user.displayAvatarURL({ format: 'png' }));

        const avatarX = 405; 
        const avatarY = 532;

        ctx.beginPath();
        ctx.arc(avatarX + avatarSize / 2, avatarY + avatarSize / 2, avatarSize / 2, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize);

        const attachment = new MessageAttachment(canvas.toBuffer(), 'welcome-image.png');

        const invites = await member.guild.invites.fetch();
        const inviter = invites.find(invite => invite.uses > 0 && invite.inviter);
        const inviterName = inviter ? `<@${inviter.inviter.id}>` : 'Unknown';
        const welcomeMessage = `**Welcome to ${member.guild.name}\n- ${member.toString()}\nYou are member number\n- ${member.guild.memberCount}\nInvited by\n- ${inviterName}**\n𝐃𝐨𝐧'𝐭 𝐟𝐨𝐫𝐠𝐨𝐭 𝐭𝐨 𝐫𝐞𝐚𝐝 𝐫𝐮𝐥𝐞𝐬`;

        const channel = member.guild.channels.cache.get(channelID);
        if (channel) {
            channel.send({ content: welcomeMessage, files: [attachment] });
        }
    } catch (error) {
        console.error('An error occurred:', error);
    }
});
//=======================================================================setchatgpt=====================================================================//
client.on('messageCreate', async message=> {
if(message.content===prefix+"set-chatgpt"){
let channel = message.mentions.channels.first()
db.set(`chatgpt-ch${message.guild.id}`,channel.id)

  message.reply("donneeeee set "+ channel)
}
})
 const openai = require("openai")
const con = new openai.Configuration({
apiKey: "sk-proj-ZsPCUsL4CxQSoazEUwm2T3BlbkFJsHoYwYIIhaFsekPhyWa2"
})
const bbd = new openai.OpenAIApi(con)

client.on('messageCreate', async messag => {

if(messag.author.bot) return;  
let channel = await db.fetch(`chatgpt-ch${messag.guild.id}`)
  if(messag.channel.id===channel){
   try{
messag.channel.sendTyping()
const m = messag.content
const a = await bbd.createChatCompletion({
        "model": "gpt-3.5-turbo-0301",
     "messages": [{"role": "user", "content": m}],
}).catch(err=>messag.reply("العديد من ناس تستخدمني الان , يرجي محاولة بعد 10 ثواني"))

  if(a.data.choices[0].message.content.length >= 2000) return messag.reply("هذي رسالة تحتوي علي الكثير من الاحرف , لا يمكنني الرد عليها")

messag.reply(a.data.choices[0].message.content.replaceAll("@here", "`here`").replaceAll("@everyone", "`everyone`"))

     } catch(err){
return;
  }
    }
  })
