const { MessageEmbed, Permissions, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
  name: 'avatar',
  description: 'Display the avatar of a user.',
  options: [
    {
      name: 'user',
      type: 'USER',
      description: 'The user to display their avatar',
      required: false,
    },
  ],
  run: async (client, interaction) => {
    const user = interaction.options.getUser('user') || interaction.user;

    const avatarEmbed = new MessageEmbed()
      .setColor("BLUE")
      .setTitle(`Avatar for ${user.tag}`)
      .setImage(user.displayAvatarURL({ dynamic: true, size: 4096 }));

    const downloadButton = new MessageButton()
      .setStyle('LINK')
      .setLabel('Avatar')
      .setURL(user.displayAvatarURL({ dynamic: true, size: 4096 }));

    const row = new MessageActionRow().addComponents(downloadButton);

    const response = {
      embeds: [avatarEmbed],
      components: [row],
    };

    if (!(interaction.guild && interaction.channel.permissionsFor(client.user).has(Permissions.FLAGS.EMBED_LINKS))) {
      response.content = `Avatar for ${user.tag}: ${user.displayAvatarURL({ dynamic: true, size: 4096 })}`;
    }

    interaction.reply(response);
  },
};
