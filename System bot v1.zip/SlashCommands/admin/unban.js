const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'unban',
  description: 'Unban a member',
  permissions: 'BAN_MEMBERS',
  options: [
    {
      name: 'user-id',
      description: 'The ID of the banned user',
      type: 'STRING',
      required: true,
    },
    {
      name: 'reason',
      description: 'The reason for unbanning the user',
      type: 'STRING',
      required: false,
    },
  ],

  run: async (client, interaction) => {
    const userId = interaction.options.getString('user-id');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!interaction.guild.me.permissions.has('BAN_MEMBERS')) {
      const noPermissionEmbed = new MessageEmbed()
        .setColor('#FF5733')
        .setDescription('❌ I don\'t have the `BAN_MEMBERS` permission.');
      return interaction.reply({ embeds: [noPermissionEmbed] });
    }

    interaction.guild.members.unban(userId, reason)
      .then(user => {
        const unbanSuccessEmbed = new MessageEmbed()
          .setColor('#28A745')
          .setTitle('Success!')
          .setDescription(`✅ Successfully unbanned user with ID \`${userId}\`!`)
          .addField('Reason:', reason)
          .setTimestamp()
          .setFooter({ text: 'Action performed by ' + interaction.user.tag, iconURL: interaction.user.displayAvatarURL() });
        interaction.reply({ embeds: [unbanSuccessEmbed] });
      })
      .catch(error => {
        console.error(`Failed to unban user: ${error}`);
        const unbanErrorEmbed = new MessageEmbed()
          .setColor('#DC3545')
          .setTitle('Error!')
          .setDescription('❌ An error occurred while trying to unban the user.')
          .setTimestamp();
        interaction.reply({ embeds: [unbanErrorEmbed] });
      });
  },
};
