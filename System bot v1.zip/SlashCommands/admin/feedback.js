const { EmbedBuilder, PermissionsBitField } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "set-feedback",
  description: "Set a feedback channel for the server.",
  options: [
    {
      name: "channel",
      description: "The channel to set as the feedback room.",
      type: 7, 
      required: true,
    },
  ],
  run: async (client, interaction) => {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setDescription("❌ **You do not have permission to use this command.**"),
          ],
          ephemeral: true,
        });
      }

      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.SendMessages)) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setDescription("❌ **I do not have permission to send messages in this channel.**"),
          ],
          ephemeral: true,
        });
      }

      const channel = interaction.options.getChannel("channel");

      if (!channel.isTextBased()) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Yellow")
              .setDescription("⚠️ **Please select a valid text channel.**"),
          ],
          ephemeral: true,
        });
      }

      db.set(`Fed_${interaction.guild.id}`, channel.id);

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Green")
            .setDescription(`✅ **Feedback room has been set to ${channel}.**`),
        ],
      });
    } catch (error) {
      console.error("Error setting feedback room:", error);

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("❌ **An error occurred while setting the feedback room.**"),
        ],
        ephemeral: true,
      });
    }
  },
};
