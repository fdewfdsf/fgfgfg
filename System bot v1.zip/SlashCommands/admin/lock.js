const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "lock",
  description: "Locks the current channel",
  category: "Moderation",
  run: async (client, message, args) => {
    if (!message.member.permissions.has("MANAGE_CHANNELS")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      return message.reply({ embeds: [embed] });
    }

    const channel = message.channel;
    const permissions = channel.permissionsFor(message.guild.roles.everyone);

    if (permissions.has("SEND_MESSAGES")) {
      try {
        await channel.permissionOverwrites.create(message.guild.roles.everyone, { SEND_MESSAGES: false });
        
        const embed = new MessageEmbed()
          .setColor("GREEN")
          .setTitle("Channel Locked")
          .setDescription("This channel has been locked. Members can no longer send messages.");

        message.reply({ embeds: [embed] });
      } catch (error) {
        console.error(error);
        const embed = new MessageEmbed()
          .setColor("RED")
          .setTitle("Error")
          .setDescription("An error occurred while trying to lock this channel. Please try again later.");

        message.reply({ embeds: [embed] });
      }
    } else {
      const embed = new MessageEmbed()
        .setColor("YELLOW")
        .setTitle("Channel Already Locked")
        .setDescription("This channel is already locked. No further action needed.");

      message.reply({ embeds: [embed] });
    }
  },
};
