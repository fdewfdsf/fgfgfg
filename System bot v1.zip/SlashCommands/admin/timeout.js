const { MessageEmbed } = require("discord.js");
const ms = require("ms");

module.exports = {
  name: "timeout",
  description: "Timeouts a user",
  category: "Moderation",
  options: [
    {
      name: "user",
      description: "The user to timeout",
      type: "USER",
      required: true
    },
    {
      name: "duration",
      description: "The duration of the timeout",
      type: "STRING",
      required: true
    },
    {
      name: "reason",
      description: "The reason for the timeout",
      type: "STRING",
      required: false
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("MANAGE_ROLES")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const duration = interaction.options.getString("duration");
    const reason = interaction.options.getString("reason") || "No reason provided";

    const timeoutDuration = ms(duration);
    if (isNaN(timeoutDuration) || timeoutDuration <= 0) {
      return interaction.reply({ content: "Invalid duration. Please provide a valid time.", ephemeral: true });
    }

    try {
      const member = interaction.guild.members.cache.get(user.id);
      await member.timeout(timeoutDuration, reason);

      const successEmbed = new MessageEmbed()
        .setColor("GREEN")
        .setTitle("User Timeout")
        .setDescription(`The user ${user.tag} has been timed out.`)
        .addField("Duration", ms(timeoutDuration, { long: true }))
        .addField("Reason", reason)
        .setTimestamp();

      interaction.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error(error);
      const errorEmbed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Error")
        .setDescription("An error occurred while trying to timeout the user.");

      interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },
};
