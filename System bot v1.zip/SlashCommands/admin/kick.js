const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "kick",
  description: "Kick a user from the server",
  category: "Moderation",
  options: [
    {
      name: "user",
      description: "The user to kick",
      type: "USER",
      required: true
    },
    {
      name: "reason",
      description: "The reason for kicking",
      type: "STRING",
      required: false
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("KICK_MEMBERS")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const reason = interaction.options.getString("reason") || "No reason provided";

    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Invalid User")
        .setDescription("The provided user is not a member of this server.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    if (!member.kickable) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Unable to Kick")
        .setDescription("I don't have sufficient permissions to kick this user.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    try {
      await member.kick(reason);
      const successEmbed = new MessageEmbed()
        .setColor("GREEN")
        .setTitle("User Kicked")
        .setDescription(`Successfully kicked ${user.tag}`)
        .addField("Reason", reason);

      interaction.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error(error);
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Error")
        .setDescription("An error occurred while trying to kick the user. Please try again later.");

      interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
