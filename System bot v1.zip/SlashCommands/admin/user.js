const { MessageEmbed } = require("discord.js");
const fs = require('fs');
const path = require('path');


module.exports = {
  name: "user",
  description: "Show information about a user.",
  options: [
    {
      name: "user",
      description: "Specify a user to get their information",
      type: "USER",
      required: false,
    },
  ],
  run: async (client, interaction, args) => {
    let targetUser;
    const userOption = interaction.options.get("user");
    
    if (userOption) {
      targetUser = userOption.user;
    } else {
      targetUser = interaction.member.user;
    }

    

    const embed = new MessageEmbed()
      .setColor("BLUE")
      .setTitle(`${targetUser.username}'s Information:`)
      .addField(serverLanguage === 'ar' ? "اسم المستخدم:" : "Username:", `<@${targetUser.id}>`)
      .addField(serverLanguage === 'ar' ? "الرقم التعريفي:" : "ID:", ` ${targetUser.id}`)
      .addField(serverLanguage === 'ar' ? "تم الإنشاء في:" : "Created At:", `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:D>`)
      .addField(serverLanguage === 'ar' ? "انضم إلى السيرفر في:" : "Joined Server At:", `<t:${Math.floor(interaction.member.joinedTimestamp / 1000)}:D>`)
      .setFooter(`Requested by ${interaction.user.username}`, interaction.user.avatarURL({ dynamic: true }))
      .setThumbnail(targetUser.avatarURL({ dynamic: true }))
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};

