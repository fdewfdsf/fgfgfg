const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "unhide",
  description: "Unhides the current channel",
  category: "Moderation",
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("MANAGE_CHANNELS")) {
      const embed = new EmbedBuilder()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const channel = interaction.channel;

    try {
      await channel.permissionOverwrites.create(interaction.guild.roles.everyone, { VIEW_CHANNEL: true });
      const embed = new EmbedBuilder()
        .setColor("GREEN")
        .setTitle("Channel Unhidden")
        .setDescription("This channel has been unhidden.");

      interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      const embed = new EmbedBuilder()
        .setColor("RED")
        .setTitle("Error")
        .setDescription("An error occurred while trying to unhide this channel.");

      interaction.reply({ embeds: [embed], ephemeral: true });
    }
  },
};
