const { MessageEmbed } = require("discord.js");
const fs = require('fs');
const path = require('path');


module.exports = {
  name: "server",
  description: "Show information about the server.",
  run: async (client, interaction, args) => {
    const serverLanguage = getServerLanguage(interaction.guild.id);

    await interaction.guild.channels.fetch();
    await interaction.guild.emojis.fetch();
    await interaction.guild.roles.fetch();

    let text = interaction.guild.channels.cache.filter(channel => channel.type === 'GUILD_TEXT').size;
    let voice = interaction.guild.channels.cache.filter(channel => channel.type === 'GUILD_VOICE').size;
    let categoryCount = interaction.guild.channels.cache.filter(channel => channel.type === 'GUILD_CATEGORY').size;

    const bans = await interaction.guild.bans.fetch();
    const banCount = bans.size;

    const regularEmojis = interaction.guild.emojis.cache.filter(emoji => !emoji.animated).size;
    const animatedEmojis = interaction.guild.emojis.cache.filter(emoji => emoji.animated).size;
    const totalEmojis = regularEmojis + animatedEmojis;

    const boostCount = interaction.guild.premiumSubscriptionCount;
    const roleCount = interaction.guild.roles.cache.size;

    const members = await interaction.guild.members.fetch();
    const onlineMembers = members.filter(member => member.presence?.status !== 'offline');
    const offlineMembers = members.filter(member => !member.presence || member.presence.status === 'offline');
    const bots = members.filter(member => member.user.bot);

    let formattedDate = interaction.guild.createdAt.toISOString().slice(0, 10);
    let createdDate = interaction.guild.createdAt;
    let timestamp = Math.floor(createdDate / 1000);

    const embed = new MessageEmbed()
      .setColor('BLUE')
      .setTitle(`${interaction.guild.name} Information`)
      .addField("Name", interaction.guild.name, true)
      .addField("ID", interaction.guild.id, true)
      .addField("Owner", `<@!${interaction.guild.ownerId}>`, true)
      .addField("Created At", `<t:${timestamp}:D>`, true)
      .addField("Members", `Total: ${members.size}\nOffline: ${offlineMembers.size}\nBots: ${bots.size}`, true)
      .addField("Channels", `Total: ${interaction.guild.channels.cache.size}\nText: ${text}\nVoice: ${voice}\nCategory: ${categoryCount}`, true)
      .addField("Emojis", `Total: ${totalEmojis}\nRegular: ${regularEmojis}\nAnimated: ${animatedEmojis}`, true)
      .addField("Server Stats", `Boosts: ${boostCount}\nRoles: ${roleCount}`, true)
      .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.avatarURL({ dynamic: true }) })
      .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};

