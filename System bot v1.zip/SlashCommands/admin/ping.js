const { MessageEmbed } = require("discord.js");
const fs = require('fs');
const path = require('path');


module.exports = {
  name: "ping",
  description: "Display the response speed of the bot.",
  run: async (client, interaction) => {
    const serverLanguage = getServerLanguage(interaction.guild.id);

    const ping = Date.now() - interaction.createdTimestamp;
    const apiPing = Math.round(client.ws.ping);

    let color;
    let latencyStatus;
    let apiLatencyStatus;
    let wsPingStatus;

    if (ping <= 100) {
      color = "GREEN";
      latencyStatus = "🟢";
    } else if (ping > 100 && ping <= 200) {
      color = "YELLOW";
      latencyStatus = "🟡";
    } else {
      color = "RED";
      latencyStatus = "🔴";
    }

    if (apiPing <= 100) {
      apiLatencyStatus = "🟢";
      wsPingStatus = "🟢";
    } else if (apiPing > 100 && apiPing <= 200) {
      apiLatencyStatus = "🟡";
      wsPingStatus = "🟡";
    } else {
      apiLatencyStatus = "🔴";
      wsPingStatus = "🔴";
    }

    const embed = new MessageEmbed()
      .setColor("BLUE")
      .setTitle(`${client.user.username} Ping`)
      .addField("Latency", `${ping}ms ${latencyStatus}`)
      .addField("API Latency", `${apiPing}ms ${apiLatencyStatus}`)
      .addField("WS Ping", `${client.ws.ping}ms ${wsPingStatus}`)
      .setFooter(`Requested by ${interaction.user.username}`, interaction.user.avatarURL({ dynamic: true }))
      .setTimestamp()
      .setThumbnail(client.user.avatarURL({ dynamic: true }));

    interaction.reply({ embeds: [embed] });
  },
};

