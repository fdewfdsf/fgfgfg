const ms = require("ms");
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'slow-mode',
  description: 'Put/Reset slowmode in channels.',
  options: [
    {
      name: 'time',
      description: 'The duration of slowmode',
      type: 3,
      required: false,
    },
  ],
  cooldown: 5,

  run: async (client, interaction, args) => {
    const channelObject = interaction.options.getChannel('channel') || interaction.channel;
    let timeoutTime = interaction.options.getString('time') || "0";
    
    if (timeoutTime === '0') {
      channelObject.setRateLimitPerUser(0);
      return interaction.reply({ content: `**:stopwatch: This channel's slowmode has been disabled.**`, ephemeral: true });
    }

    const time = ms(timeoutTime);
    
    if (isNaN(time) || time > 21600000 || time <= 0) {
      return interaction.reply({ content: `**__${timeoutTime}__ is not a valid time. Please specify a time between 1s and 6h.**`, ephemeral: true });
    }

    channelObject.setRateLimitPerUser(time / 1000);
    
    return interaction.reply({ content: `**✅ Slowmode has been set to ${ms(time, { long: true })}.**`, ephemeral: true });
  }
};
