const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "clear",
  description: "Clear a specified number of messages.",
  options: [
    {
      name: "amount",
      description: "The number of messages to clear (between 1 and 100).",
      type: 4, // INTEGER
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const amount = interaction.options.getInteger("amount");

    if (amount < 1 || amount > 100) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("❌ **Please provide a number between 1 and 100.**"),
        ],
        ephemeral: true,
      });
    }

    if (!interaction.member.permissions.has("ManageMessages")) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("❌ **You do not have permission to manage messages.**"),
        ],
        ephemeral: true,
      });
    }

    if (!interaction.guild.me.permissions.has("ManageMessages")) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("❌ **I do not have permission to manage messages in this channel.**"),
        ],
        ephemeral: true,
      });
    }

    try {
      const deletedMessages = await interaction.channel.bulkDelete(amount, true); 
      if (deletedMessages.size === 0) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Yellow")
              .setDescription("⚠️ **No messages could be deleted. Make sure they are not older than 14 days.**"),
          ],
          ephemeral: true,
        });
      }

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Green")
            .setDescription(`✅ **Successfully cleared ${deletedMessages.size} message(s).**`),
        ],
        ephemeral: true,
      });
    } catch (error) {
      console.error("Error clearing messages:", error);

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("❌ **An error occurred while trying to clear messages.**"),
        ],
        ephemeral: true,
      });
    }
  },
};
