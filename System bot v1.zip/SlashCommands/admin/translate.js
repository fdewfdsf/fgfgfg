const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const path = require('path');
const translate = require('@iamtraction/google-translate');


module.exports = {
  name: "translate",
  description: "Translate text between languages",
  options: [
    {
      name: "text",
      description: "The text to translate",
      type: "STRING",
      required: true,
    },
    {
      name: "source",
      description: "The source language (e.g., en, ar)",
      type: "STRING",
      required: true,
    },
    {
      name: "target",
      description: "The target language (e.g., en, ar)",
      type: "STRING",
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const text = interaction.options.getString("text");
    const sourceLang = interaction.options.getString("source");
    const targetLang = interaction.options.getString("target");


    try {
      const result = await translate(text, { from: sourceLang, to: targetLang });
      const translatedText = result.text;

      await interaction.reply(`**Translated text:** __**${translatedText}**__`);
    } catch (error) {
      console.error(error);
      await interaction.reply("An error occurred while translating the text.");
    }
  },
};

