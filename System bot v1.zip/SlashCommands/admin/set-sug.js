const { EmbedBuilder, PermissionsBitField } = require('discord.js');
let db = require('pro.db');

module.exports = {
  name: "set-sug",
  description: "Set a suggestions channel",
  options: [
    {
      name: "channel",
      description: "Channel to set as the suggestions channel",
      type: 7,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: "You don't have permission to use this command.",
          ephemeral: true,
        });
      }

      const channel = interaction.options.getChannel("channel");
      const channelId = channel.id;

      await db.set(`Sug_${interaction.guild.id}`, channelId);

      const embed = new EmbedBuilder()
        .setColor("GREEN")
        .setTitle("Suggestions Channel Set")
        .setDescription(`The suggestions channel has been successfully set to ${channel}.`);

      interaction.reply({ embeds: [embed] });

    } catch (err) {
      console.error(err);
      interaction.reply({
        content: "An error occurred while setting the suggestions channel.",
        ephemeral: true,
      });
    }
  },
};
