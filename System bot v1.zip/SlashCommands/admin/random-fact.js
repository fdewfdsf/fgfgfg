const axios = require('axios');
const { MessageEmbed } = require('discord.js');
const fs = require('fs');
const path = require('path');


module.exports = {
  name: 'random-fact',
  description: 'Get a random fact in the appropriate language',
  run: async (client, interaction) => {
    try {
      const serverLanguage = getServerLanguage(interaction.guild.id);

      const response = await axios.get('https://useless-facts.sameerkumar.website/api');
      const fact = response.data.data;

      const embed = new MessageEmbed()
        .setColor('BLUE')
        .setTitle('Random Fact')
        .setDescription(fact);

      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      await interaction.reply('An error occurred while fetching a random fact.');
    }
  },
};

