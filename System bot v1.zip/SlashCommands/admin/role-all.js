const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "role-all",
  description: "Give a specific role to all server members",
  options: [
    {
      name: "role",
      description: "The role to give to members",
      type: "ROLE",
      required: true,
    },
    {
      name: "target",
      description: "The target to give the role to",
      type: "STRING",
      required: true,
      choices: [
        { name: "Human", value: "human" },
        { name: "Bot", value: "bot" },
      ],
    },
  ],
  run: async (client, interaction) => {
    const role = interaction.options.getRole("role");
    const target = interaction.options.getString("target");

    if (!role) {
      return interaction.reply({
        content: "Please provide a valid role.",
        ephemeral: true,
      });
    }

    if (!interaction.guild.me.permissions.has("MANAGE_ROLES")) {
      return interaction.reply({
        content: "I don't have the permission to manage roles in this server.",
        ephemeral: true,
      });
    }

    let members;
    let targetName;

    if (target === "human") {
      members = interaction.guild.members.cache.filter(
        (member) => !member.user.bot
      );
      targetName = "human members";
    } else if (target === "bot") {
      members = interaction.guild.members.cache.filter(
        (member) => member.user.bot
      );
      targetName = "bots";
    } else {
      return interaction.reply({
        content: "Please select a valid target.",
        ephemeral: true,
      });
    }

    try {
      const addPromises = members.map((member) => member.roles.add(role));
      await Promise.all(addPromises);

      const embed = new MessageEmbed()
        .setColor("GREEN")
        .setDescription(
          `Successfully added the role \`${role.name}\` to all ${targetName}.`
        );
      interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      return interaction.reply({
        content: "An error occurred while adding the role.",
        ephemeral: true,
      });
    }
  },
};
