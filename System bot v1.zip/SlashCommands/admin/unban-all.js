const { EmbedBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
  name: "unban-all",
  description: "To unban all members in the ban list",

  run: async (client, interaction) => {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers)) {
        return interaction.reply({
          content: "** 😕 You don't have permission to unban members. **",
          ephemeral: true
        });
      }

      const guild = interaction.guild;
      const bans = await guild.bans.fetch();

      if (bans.size === 0) {
        return interaction.reply({
          content: "**There are no banned members in this server.**",
          ephemeral: true
        });
      }

      bans.forEach(async (ban) => {
        try {
          await guild.members.unban(ban.user.id);
        } catch (error) {
          console.error(`Failed to unban ${ban.user.tag}:`, error);
        }
      });

      interaction.reply({
        content: "> **Done! All banned members have been unbanned.**"
      });

    } catch (err) {
      console.error(err);
      interaction.reply({
        content: "**An error occurred while trying to unban all members.**",
        ephemeral: true
      });
    }
  }
};
