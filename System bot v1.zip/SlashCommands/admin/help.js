const { MessageEmbed, MessageButton, MessageActionRow, MessageSelectMenu } = require("discord.js");
const fs = require('fs');
const path = require('path');


module.exports = {
    name: "help",
    description: "Displays a list of commands for the bot.",
    run: async (client, interaction, args) => {
        try {
            const serverLanguage = getServerLanguage(interaction.guild.id);

            const generalCommands = `**General Commands**
            /avatar: Display the avatar of a user.
            /banner: Display the banner of a user.
            /tax probot: Display Probot Credit Tax.
            /role-info: Display Role Information.
            /invite: Get an invite link for the bot.
            /random-fact: Display a random fact.
            /user: Display information about a user.
            /server: Display information about the server.
            /all-bots: Show all bots in the server.
            /uptime: Display the bot's uptime.
            /draw: Draw something.
            /ping: Check the bot's latency.
            /help: Display a list of available commands.
            /bot-info: Display information about the bot.`;

            const moderationCommands = `**Moderation Commands**
            /ban: Ban a user.
            /unban: Unban a user.
            /mute: Mute a user.
            /unmute: Unmute a user.
            /lock: Lock a channel.
            /unlock: Unlock a channel.
            /hide: Hide a channel.
            /hide-all: To Hide All channels.
            /unhide-all: To Show All channels.
            /unhide: Unhide a channel.
            /timeout: Timeout a user.
            /untimeout: Remove the timeout from a user.
            /clear: Clear messages from a channel.
            /role-all: Add/remove a role to/from all users.
            /role: Add/remove a role to/from a user.
            /set-sug: To Set a Suggestions Channel.
            /set-ai-chat: To Set a Chat gpt Channel.
            /set-welcome: To Set a Welcome Channel.
            /unban-all: To UnBan All Members In BanList.
            /temp-role: To Give Someone a Temp Role.
            /slow-mode: To Set a Slow Mode On Messages.
            /set-feedback: To set a Feedback Channel.
            /say: Make the bot say something.
            /embed: Create an embedded message.
            /hook: Send a message using a webhook.`;

            const badwordCommands = `**Badword Commands**
            /add-bad-word: Add a bad word to the filter list.
            /remove-bad-word: Remove a bad word from the filter list.
            /list-bad-words: List all the bad words in the filter list.
            /check-bad-word: Check if a message contains a bad word.
            /help-badword: Display help for the badword commands.`;

            const lineCommands = `**Line Commands**
            /set-line: Set a line for the bot to respond with.
            /add-auto-line: Add an automated response line.
            /remove-auto-line: Remove an automated response line.
            /list-auto-line: List all the automated response lines.
            /line: Get the selected line you set.
            /help-line: Display help for the line commands.`;

            const autoReplyCommands = `**Auto Reply Commands**
            /add-auto-reply: Add an auto reply message.
            /remove-auto-reply: Remove an auto reply message.
            /help-auto-reply: Display help for the auto reply commands.`;

            const protectionCommands = `**Protection Commands**
            /antibot on: Enable anti-bot protection.
            /antibot off: Disable anti-bot protection.`;

            const categories = {
                general: generalCommands,
                moderation: moderationCommands,
                badword: badwordCommands,
                line: lineCommands,
                autoReply: autoReplyCommands,
                protection: protectionCommands,
            };

            const embed = new MessageEmbed()
                .setDescription(categories.general)
                .setColor("BLUE")
                .setThumbnail(interaction.user.avatarURL({ dynamic: true }))
                .setTimestamp();

            const row = new MessageActionRow()
                .addComponents(
                    new MessageSelectMenu()
                        .setCustomId('select-category')
                        .setPlaceholder('Select a category')
                        .addOptions([
                            { label: 'General Commands', value: 'general' },
                            { label: 'Moderation Commands', value: 'moderation' },
                            { label: 'Badword Commands', value: 'badword' },
                            { label: 'Line Commands', value: 'line' },
                            { label: 'Auto Reply Commands', value: 'autoReply' },
                            { label: 'Protection Commands', value: 'protection' },
                        ]),
                );

            const message = await interaction.reply({ embeds: [embed], components: [row], fetchReply: true });

            const filter = i => i.customId === 'select-category' && i.user.id === interaction.user.id;
            const collector = message.createMessageComponentCollector({ filter, time: 100000 });

            collector.on('collect', async i => {
                if (i.isSelectMenu()) {
                    const selectedCategory = i.values[0];
                    embed.setDescription(categories[selectedCategory]);
                    await i.update({ embeds: [embed] });
                }
            });

            collector.on('end', collected => {
                message.edit({ components: [] });
            });
        } catch (error) {
            console.error('An error occurred while running the help command:', error);
            interaction.reply({ content: 'An error occurred while running the command. Please try again later.', ephemeral: true });
        }
    }
};


