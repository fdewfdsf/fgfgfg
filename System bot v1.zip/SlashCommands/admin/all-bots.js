const { MessageEmbed, Permissions, MessageActionRow, MessageButton } = require('discord.js');
const fs = require('fs');
const path = require('path');

const LANGUAGES_FILE = path.join(__dirname, 'serverLanguages.json');

module.exports = {
  name: "all-bots",
  description: "Show all bots in the server",

  run: async (client, interaction, args) => {
    try {
      if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
        return interaction.reply({
          content: "🥺 **You don't have permissions**",
          ephemeral: true
        });
      }

      const bots = interaction.guild.members.cache.filter(member => member.user.bot);
      const botCount = bots.size;

      if (botCount === 0) {
        return interaction.reply({
          content: "🤖 **There are no bots in this server!**",
          ephemeral: true
        });
      }

      const botsPerPage = 10;
      const totalPages = Math.ceil(botCount / botsPerPage);
      let currentPage = 1;

      const generateEmbed = (page) => {
        const start = (page - 1) * botsPerPage;
        const end = start + botsPerPage;
        const botList = bots.map(bot => `<@${bot.id}>`).slice(start, end).join('\n');

        return new MessageEmbed()
          .setTitle(`🤖 Bots in ${interaction.guild.name}`)
          .setDescription(`**There are ${botCount} bots in this server!**\n${botList}`)
          .setColor("RANDOM")
          .setFooter({ text: `Page ${page} of ${totalPages}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
          .setTimestamp();
      };

      const row = new MessageActionRow()
        .addComponents(
          new MessageButton()
            .setCustomId('prev')
            .setEmoji('⬅️')
            .setStyle('SECONDARY')
            .setDisabled(currentPage === 1),
          new MessageButton()
            .setCustomId('next')
            .setEmoji('➡️')
            .setStyle('SECONDARY')
            .setDisabled(currentPage === totalPages)
        );

      const message = await interaction.reply({ embeds: [generateEmbed(currentPage)], components: [row], fetchReply: true });

      const collector = message.createMessageComponentCollector({ time: 60000 });

      collector.on('collect', async i => {
        if (i.user.id !== interaction.user.id) {
          return i.reply({ content: "🚫 **You can't interact with this button!**", ephemeral: true });
        }

        if (i.customId === 'prev' && currentPage > 1) {
          currentPage--;
        } else if (i.customId === 'next' && currentPage < totalPages) {
          currentPage++;
        }

        await i.update({ embeds: [generateEmbed(currentPage)], components: [
          new MessageActionRow()
            .addComponents(
              new MessageButton()
                .setCustomId('prev')
                .setEmoji('⬅️')
                .setStyle('SECONDARY')
                .setDisabled(currentPage === 1),
              new MessageButton()
                .setCustomId('next')
                .setEmoji('➡️')
                .setStyle('SECONDARY')
                .setDisabled(currentPage === totalPages)
            )
        ] });
      });

      collector.on('end', collected => {
        message.edit({ components: [] });
      });
    } catch (err) {
      console.error(err);
      interaction.reply({ content: '⚠️ **There was an unexpected error!**', ephemeral: true });
    }
  }
};
