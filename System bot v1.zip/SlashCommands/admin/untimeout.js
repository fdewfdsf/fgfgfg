const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "untimeout",
  description: "Untimeouts a user",
  category: "Moderation",
  options: [
    {
      name: "user",
      description: "The user to untimeout",
      type: "USER",
      required: true
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("MANAGE_ROLES")) {
      const embed = new EmbedBuilder()
        .setColor("#FF5733")
        .setTitle("Permission Denied")
        .setDescription("❌ You don't have permission to use this command.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const member = await interaction.guild.members.fetch(user.id);

    if (!member.communicationDisabledUntil) {
      const embed = new EmbedBuilder()
        .setColor("#FFCC00")
        .setTitle("User Not Timed Out")
        .setDescription(`🔊 The user ${user.tag} does not have an active timeout.`);

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    try {
      await member.timeout(null);
      const successEmbed = new EmbedBuilder()
        .setColor("#28A745")
        .setTitle("User Untimed Out")
        .setDescription(`✅ The user ${user.tag} has been untimed out.`);

      interaction.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error(error);
      const errorEmbed = new EmbedBuilder()
        .setColor("#DC3545")
        .setTitle("Error")
        .setDescription("❌ An error occurred while trying to untimeout the user.");

      interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },
};
