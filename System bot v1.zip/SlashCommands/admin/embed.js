const { PermissionsBitField, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "embed",
  description: "Send a custom embed message.",
  options: [
    {
      name: "content",
      type: 3, 
      description: "The content of the embed.",
      required: true,
    },
    {
      name: "color",
      type: 3, 
      description: "The color of the embed (HEX or basic color name).",
      required: false,
    },
    {
      name: "title",
      type: 3, 
      description: "The title of the embed.",
      required: false,
    },
    {
      name: "image",
      type: 3, 
      description: "The image URL for the embed.",
      required: false,
    },
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply({
        content: "❌ **You do not have permission to use this command.**",
        ephemeral: true,
      });
    }

    if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.SendMessages)) {
      return interaction.reply({
        content: "❌ **I do not have permission to send messages in this channel.**",
        ephemeral: true,
      });
    }

    const content = interaction.options.getString("content");
    const color = interaction.options.getString("color") || "#00FF00"; 
    const title = interaction.options.getString("title");
    const image = interaction.options.getString("image");

    if (image && !image.match(/^https?:\/\/[^\s]+$/)) {
      return interaction.reply({
        content: "❌ **Please provide a valid image URL.**",
        ephemeral: true,
      });
    }

    try {
      const embed = new EmbedBuilder().setDescription(content).setColor(color);

      if (title) embed.setTitle(title);
      if (image) embed.setImage(image);

      await interaction.channel.send({ embeds: [embed] });

      interaction.reply({
        content: "✅ **Embed message sent successfully!**",
        ephemeral: true,
      });
    } catch (error) {
      console.error("Error sending embed:", error);

      interaction.reply({
        content: "❌ **An error occurred while sending the embed message.**",
        ephemeral: true,
      });
    }
  },
};
