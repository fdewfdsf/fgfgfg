const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: "unhide-all",
  description: "Show all server channels",

  run: async (client, interaction, args) => {
    try {
      if (!interaction.member.permissions.has('MANAGE_CHANNELS')) {
        const noPermissionEmbed = new EmbedBuilder()
          .setColor('#FF5733')
          .setDescription('❌ You don\'t have the necessary permissions to manage channels.');
        return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
      }

      if (!interaction.guild.me.permissions.has('MANAGE_CHANNELS')) {
        const botNoPermissionEmbed = new EmbedBuilder()
          .setColor('#FF5733')
          .setDescription('❌ I couldn\'t edit the channel permissions. Please check my permissions and role position.');
        return interaction.reply({ embeds: [botNoPermissionEmbed], ephemeral: true });
      }

      interaction.guild.channels.cache.each((channel) => {
        channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
          VIEW_CHANNEL: true
        });
      });

      const successEmbed = new EmbedBuilder()
        .setColor('#28A745')
        .setDescription('✅ All server channels are now visible.');

      interaction.reply({ embeds: [successEmbed], ephemeral: true });
    } catch (err) {
      console.log(err);
      const errorEmbed = new EmbedBuilder()
        .setColor('#DC3545')
        .setDescription('❌ An error occurred while trying to unhide the channels.');

      interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  }
};
