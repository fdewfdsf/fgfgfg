const { PermissionsBitField, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "hook-embed",
  description: "Send a custom embed message using a webhook.",
  options: [
    {
      name: "content",
      type: 3,
      description: "The content of the embed.",
      required: true,
    },
    {
      name: "color",
      type: 3,
      description: "The color of the embed (hex code or predefined).",
      required: false,
    },
    {
      name: "title",
      type: 3,
      description: "The title of the embed.",
      required: false,
    },
    {
      name: "image",
      type: 3,
      description: "The image URL for the embed.",
      required: false,
    },
  ],
  run: async (client, interaction) => {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply({
          content: "❌ **You don't have permission to use this command.**",
          ephemeral: true,
        });
      }

      const content = interaction.options.getString("content");
      const color = interaction.options.getString("color") || "Random";
      const title = interaction.options.getString("title");
      const image = interaction.options.getString("image");

      const channel = interaction.channel;
      const server = interaction.guild;

      const webhook = await channel.createWebhook({
        name: server.name,
        avatar: server.iconURL({ dynamic: true }),
      });

      const embed = new EmbedBuilder()
        .setDescription(content)
        .setColor(color);

      if (title) embed.setTitle(title);
      if (image) embed.setImage(image);

      await webhook.send({ embeds: [embed] });

      await webhook.delete();

      interaction.reply({
        content: "✅ **Embed message sent successfully via webhook.**",
        ephemeral: true,
      });
    } catch (error) {
      console.error("Error executing hook-embed command:", error);

      interaction.reply({
        content: "❌ **An error occurred while executing this command.**",
        ephemeral: true,
      });
    }
  },
};
