const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "hide",
  description: "Hides the current channel from everyone.",
  category: "Moderation",
  run: async (client, message) => {
    try {
      if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setTitle("Permission Denied")
              .setDescription("❌ **You do not have permission to use this command.**"),
          ],
        });
      }

      if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return message.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setTitle("Insufficient Permissions")
              .setDescription(
                "❌ **I do not have the required permissions to manage channel settings.**"
              ),
          ],
        });
      }

      const channel = message.channel;

      await channel.permissionOverwrites.edit(message.guild.roles.everyone, {
        ViewChannel: false,
      });

      const successEmbed = new EmbedBuilder()
        .setColor("Green")
        .setTitle("Channel Hidden")
        .setDescription("✅ **This channel has been successfully hidden from everyone.**");

      message.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error("Error hiding channel:", error);

      const errorEmbed = new EmbedBuilder()
        .setColor("Red")
        .setTitle("Error")
        .setDescription("❌ **An error occurred while trying to hide this channel.**");

      message.reply({ embeds: [errorEmbed] });
    }
  },
};
