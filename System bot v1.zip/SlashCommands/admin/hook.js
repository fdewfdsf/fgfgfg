const { PermissionsBitField, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "hook",
  description: "Send a message using a webhook",
  options: [
    {
      name: "message",
      type: 3,
      description: "The message to be sent",
      required: true,
    },
    {
      name: "image",
      type: 3,
      description: "The image to be sent",
      required: false,
    },
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply({
        content: "You don't have permission to use this command.",
        ephemeral: true,
      });
    }

    const messageContent = interaction.options.getString("message");
    const image = interaction.options.getString("image");

    const channel = interaction.channel;
    const webhooks = await channel.fetchWebhooks();

    if (webhooks.size > 0) {
      const oldWebhook = webhooks.first();
      await oldWebhook.delete();
    }

    const webhook = await channel.createWebhook(interaction.guild.name, {
      avatar: interaction.guild.iconURL(),
    });

    const payload = {
      content: messageContent,
      username: interaction.guild.name,
      avatarURL: interaction.guild.iconURL(),
    };

    if (image) {
      payload.files = [image];
    }

    try {
      await webhook.send(payload);
      await webhook.delete();
      interaction.reply({
        content: "✅ Message successfully sent using webhook.",
        ephemeral: true,
      });
    } catch (error) {
      console.error("Webhook error:", error);
      interaction.reply({
        content: "❌ An error occurred while sending the message via webhook.",
        ephemeral: true,
      });
    }
  },
};
