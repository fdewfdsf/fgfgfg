const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'ban',
  description: 'Ban a user from the server.',
  options: [
    {
      name: 'user',
      description: 'The user to ban.',
      type: 6, 
      required: true,
    },
    {
      name: 'duration',
      description: 'The duration of the ban (e.g., 1h, 1d).',
      type: 3, 
      required: false,
    },
    {
      name: 'reason',
      description: 'The reason for the ban.',
      type: 3, 
      required: false,
    },
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has('BanMembers')) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ **You do not have the required permissions to ban members.**'),
        ],
        ephemeral: true,
      });
    }

    if (!interaction.guild.me.permissions.has('BanMembers')) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ **I do not have the required permissions to ban members.**'),
        ],
        ephemeral: true,
      });
    }

    const user = interaction.options.getMember('user');
    const duration = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    if (!user) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ **User not found. Please mention a valid user or provide their ID.**'),
        ],
        ephemeral: true,
      });
    }

    if (
      user.roles.highest.position >= interaction.member.roles.highest.position &&
      interaction.user.id !== interaction.guild.ownerId
    ) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ **You cannot ban this user due to role hierarchy.**'),
        ],
        ephemeral: true,
      });
    }

    if (!user.bannable) {
      return interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ **I cannot ban this user. Make sure my role is higher than their role.**'),
        ],
        ephemeral: true,
      });
    }

    try {
      await user.ban({ reason });
      const banEmbed = new EmbedBuilder()
        .setColor('Green')
        .setTitle('✅ User Banned')
        .setDescription(`**${user.user.tag} has been banned from the server.**`)
        .addFields(
          { name: 'Reason', value: reason, inline: true },
          { name: 'Duration', value: duration || 'Permanent', inline: true },
        );

      interaction.reply({ embeds: [banEmbed] });

      if (duration) {
        const ms = parseDuration(duration);
        if (ms) {
          setTimeout(async () => {
            try {
              await interaction.guild.members.unban(user.id, 'Ban duration expired');
              const unbanEmbed = new EmbedBuilder()
                .setColor('Yellow')
                .setTitle('🔄 User Unbanned')
                .setDescription(`**${user.user.tag} has been unbanned after the ban duration expired.**`);
              interaction.followUp({ embeds: [unbanEmbed] });
            } catch (err) {
              console.error('Error unbanning user:', err);
            }
          }, ms);
        } else {
          interaction.followUp({
            embeds: [
              new EmbedBuilder()
                .setColor('Orange')
                .setDescription('⚠️ **Invalid duration format. The ban will be permanent.**'),
            ],
            ephemeral: true,
          });
        }
      }
    } catch (err) {
      console.error('Error banning user:', err);
      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('Red')
            .setDescription('❌ **An error occurred while trying to ban the user.**'),
        ],
        ephemeral: true,
      });
    }
  },
};

function parseDuration(duration) {
  const match = duration.match(/^(\d+)([smhd])$/);
  if (!match) return null;

  const value = parseInt(match[1], 10);
  const unit = match[2];
  const multipliers = { s: 1000, m: 60 * 1000, h: 60 * 60 * 1000, d: 24 * 60 * 60 * 1000 };
  return value * (multipliers[unit] || 0);
}
