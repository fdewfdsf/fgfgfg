const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "role",
  description: "Give a specific role to a specific member",
  options: [
    {
      name: "member",
      description: "The member to give the role to",
      type: "USER",
      required: true,
    },
    {
      name: "role",
      description: "The role to give to the member",
      type: "ROLE",
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const member = interaction.options.getMember("member");
    const role = interaction.options.getRole("role");

    if (!member) {
      return interaction.reply({
        content: "Please provide a valid member.",
        ephemeral: true,
      });
    }

    if (!role) {
      return interaction.reply({
        content: "Please provide a valid role.",
        ephemeral: true,
      });
    }

    if (!interaction.guild.me.permissions.has("MANAGE_ROLES")) {
      return interaction.reply({
        content: "I don't have the permission to manage roles in this server.",
        ephemeral: true,
      });
    }

    if (member.roles.highest.position >= interaction.guild.members.me.roles.highest.position) {
      return interaction.reply({
        content: "I cannot assign this role to a member with a higher or equal role than mine.",
        ephemeral: true,
      });
    }

    try {
      await member.roles.add(role);
      const embed = new MessageEmbed()
        .setColor("GREEN")
        .setDescription(`Successfully added the role \`${role.name}\` to ${member.user.tag}`);
      interaction.reply({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      return interaction.reply({
        content: "An error occurred while adding the role.",
        ephemeral: true,
      });
    }
  },
};
