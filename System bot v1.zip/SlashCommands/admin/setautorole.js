const { MessageEmbed } = require('discord.js');
let db = require('pro.db');

module.exports = {
  name: "setautorole",
  description: "Set an auto role for new members",
  options: [
    {
      name: "role",
      description: "The role to set as the auto role",
      type: 8,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    try {
      const role = interaction.options.getRole('role');
      const guildId = interaction.guild.id;

      await db.set(`AutoRole_${guildId}`, role.id); 

      const embed = new MessageEmbed()
        .setTitle("Auto Role Set")
        .setColor('#7800FF')
        .setDescription(`The auto role has been successfully set to: \`${role.name}\``)
        .setTimestamp()
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

      interaction.reply({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      interaction.reply({ content: 'There was an error while setting the auto role.', ephemeral: true });
    }
  },
};
