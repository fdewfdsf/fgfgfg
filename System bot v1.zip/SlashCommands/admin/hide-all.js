const { EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
  name: "hide-all",
  description: "Hide all server channels from everyone.",

  run: async (client, interaction) => {
    try {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setDescription("❌ **You do not have permission to use this command.**"),
          ],
          ephemeral: true,
        });
      }

      if (!interaction.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
        return interaction.reply({
          embeds: [
            new EmbedBuilder()
              .setColor("Red")
              .setDescription(
                "❌ **I do not have the necessary permissions to edit channel settings. Please check my role position and permissions.**"
              ),
          ],
          ephemeral: true,
        });
      }

      interaction.guild.channels.cache.forEach((channel) => {
        channel.permissionOverwrites
          .edit(channel.guild.roles.everyone, {
            ViewChannel: false,
          })
          .catch((error) => console.error(`Failed to hide channel: ${channel.name}`, error));
      });

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Green")
            .setDescription("✅ **All server channels have been successfully hidden.**"),
        ],
        ephemeral: true,
      });
    } catch (error) {
      console.error("Error hiding channels:", error);

      interaction.reply({
        embeds: [
          new EmbedBuilder()
            .setColor("Red")
            .setDescription("❌ **An error occurred while trying to hide the channels.**"),
        ],
        ephemeral: true,
      });
    }
  },
};
