const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
    name: "banner",
    description: "Displays the banner of a user.",
    options: [
        {
            name: "user",
            description: "The user to display the banner for",
            type: "USER",
            required: false,
        },
    ],
    async run(client, interaction) {
        let user = interaction.options.getMember('user') || interaction.member;
        let banner = false;
        await user.user.fetch();
        if (user.user.banner) {
            banner = user.user.bannerURL({ dynamic: true, size: 1024 });
        }

        if (banner === false) {
            return interaction.reply({
                content: `**This user \`${user.user.username}\` doesn't have a banner!**`, 
                ephemeral: true 
            });
        }

        const embed = new MessageEmbed()
            .setColor("BLUE")
            .setTitle(`${user.user.username}'s Banner`)
            .setURL(banner)
            .setImage(banner)
            .setFooter(`Requested by ${interaction.user.username}`, interaction.user.displayAvatarURL({ dynamic: true }))
            .setTimestamp();

        const row = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setLabel('Banner')
                    .setStyle('LINK')
                    .setURL(banner)
            );

        interaction.reply({ embeds: [embed], components: [row] });
    },
};
