const { MessageEmbed } = require('discord.js');
const moment = require('moment');

module.exports = {
  name: "inrole",
  description: "Get more info about a specific role",
  options: [
    {
      name: "role",
      description: "The role to get information about",
      type: 8, // ROLE type
      required: true,
    },
  ],

  run: async (client, interaction) => {
    try {
      const role = interaction.options.getRole('role');
      const membersWithRole = interaction.guild.roles.cache
        .get(role.id)
        .members.map(member => `**<@${member.id}> ( ${member.id} )**`)
        .join("\n");

      const embed = new MessageEmbed()
        .setTitle(`Information About Role: \`${role.name}\``)
        .setColor('#7800FF')
        .setDescription(`
          **Role Name:** \`${role.name}\`
          
          **Members Count with this Role:** \`${interaction.guild.roles.cache.get(role.id).members.size}\`
          
          **Members with this Role:**
          ${membersWithRole}
          
          **Role Created At:** \`${moment(role.createdAt).format('DD/MM/YYYY h:mm')}\`
        `)
        .setTimestamp()
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

      interaction.reply({ embeds: [embed], split: true });
    } catch (err) {
      console.error(err);
      interaction.reply({ content: "An error occurred while retrieving the role information.", ephemeral: true });
    }
  },
};
