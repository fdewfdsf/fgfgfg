const { Permissions } = require("discord.js");

module.exports = {
  name: "say",
  description: "Repeat what the user says",
  options: [
    {
      name: "message",
      type: "STRING",
      description: "The message to be sent",
      required: true,
    },
    {
      name: "image",
      type: "STRING",
      description: "The image to be sent",
      required: false,
    },
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.reply({
        content: "You don't have permission to use this command.",
        ephemeral: true,
      });
    }

    const message = interaction.options.getString("message");
    const image = interaction.options.getString("image");

    const reply = {
      content: message,
    };

    if (image) {
      reply.files = [image];
    }

    try {
      await interaction.channel.send(reply);
      await interaction.reply({
        content: "Message sent successfully.",
        ephemeral: true,
      });
    } catch (error) {
      console.error(error);
      await interaction.reply({
        content: "An error occurred while sending the message.",
        ephemeral: true,
      });
    }

    interaction.delete();
  },
};
