const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "mute",
  description: "Mutes a user",
  category: "Moderation",
  options: [
    {
      name: "user",
      description: "The user to mute",
      type: "USER",
      required: true
    },
    {
      name: "duration",
      description: "The duration of the mute",
      type: "STRING",
      required: false
    },
    {
      name: "reason",
      description: "The reason for the mute",
      type: "STRING",
      required: false
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("MUTE_MEMBERS")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const duration = interaction.options.getString("duration");
    const reason = interaction.options.getString("reason") || "No reason provided";

    const member = interaction.guild.members.cache.get(user.id);

    if (!member) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Invalid User")
        .setDescription("The provided user is not a member of this server.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    try {
      await member.voice.setMute(true, reason);

      const successEmbed = new MessageEmbed()
        .setColor("GREEN")
        .setTitle("User Muted")
        .setDescription(`The user ${user.tag} has been muted.`)
        .addField("Duration", duration || "Permanent")
        .addField("Reason", reason);

      interaction.reply({ embeds: [successEmbed] });
      
      if (duration) {
        setTimeout(async () => {
          await member.voice.setMute(false);
        }, ms(duration));
      }
    } catch (error) {
      console.error(error);
      const errorEmbed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Error")
        .setDescription("An error occurred while trying to mute the user.");

      interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },
};
