const { EmbedBuilder } = require('discord.js');
let db = require('pro.db');

module.exports = {
  name: "set-welcome",
  description: "Set a welcome channel for new members",
  options: [
    {
      name: "channel",
      description: "Channel to set as the welcome channel",
      type: 7,
      required: true,
    },
  ],

  run: async (client, interaction) => {
    try {
      if (!interaction.member.permissions.has('ADMINISTRATOR')) {
        return interaction.reply({ 
          content: "** 😕 You don't have permission **", 
          ephemeral: true 
        });
      }

      const channel = interaction.options.getChannel('channel');
      const channelId = channel.id;

      await db.set(`welcome_${interaction.guild.id}`, channelId);

      const embed = new EmbedBuilder()
        .setTitle("Welcome Channel Set")
        .setColor('#7800FF')
        .setDescription(`The welcome channel has been successfully set to: ${channel}`)
        .setTimestamp()
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
        .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

      interaction.reply({ embeds: [embed] });
    } catch (err) {
      console.error(err);
      interaction.reply({ content: 'There was an error while setting the welcome channel.', ephemeral: true });
    }
  },
};
