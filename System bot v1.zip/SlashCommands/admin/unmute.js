const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "unmute",
  description: "Unmutes a user",
  category: "Moderation",
  options: [
    {
      name: "user",
      description: "The user to unmute",
      type: "USER",
      required: true
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("MUTE_MEMBERS")) {
      const embed = new EmbedBuilder()
        .setColor('#FF5733')
        .setTitle("Permission Denied")
        .setDescription("❌ You don't have permission to use this command.");

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    const user = interaction.options.getUser("user");
    const member = await interaction.guild.members.fetch(user.id);

    if (!member.voice.serverMute) {
      const embed = new EmbedBuilder()
        .setColor('#FFCC00')
        .setTitle("User Not Muted")
        .setDescription(`🔊 The user ${user.tag} is not muted.`);

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    try {
      await member.voice.setMute(false);
      const successEmbed = new EmbedBuilder()
        .setColor('#28A745')
        .setTitle("User Unmuted")
        .setDescription(`✅ The user ${user.tag} has been unmuted.`);

      interaction.reply({ embeds: [successEmbed] });
    } catch (error) {
      console.error(error);
      const errorEmbed = new EmbedBuilder()
        .setColor('#DC3545')
        .setTitle("Error")
        .setDescription("❌ An error occurred while trying to unmute the user.");

      interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },
};
