const { EmbedBuilder } = require("discord.js");

module.exports = {
  name: "unlock",
  description: "Unlocks the current channel",
  category: "Moderation",
  run: async (client, message, args) => {
    if (!message.member.permissions.has("MANAGE_CHANNELS")) {
      const embed = new EmbedBuilder()
        .setColor('#FF5733')
        .setTitle("Permission Denied")
        .setDescription("❌ You don't have permission to use this command.");
      
      return message.reply({ embeds: [embed] });
    }

    const channel = message.channel;
    const permissions = channel.permissionsFor(message.guild.roles.everyone);

    if (!permissions.has("SEND_MESSAGES")) {
      try {
        await channel.permissionOverwrites.create(message.guild.roles.everyone, { SEND_MESSAGES: null });
        const embed = new EmbedBuilder()
          .setColor('#28A745')
          .setTitle("Channel Unlocked")
          .setDescription("✅ This channel has been successfully unlocked.");

        message.reply({ embeds: [embed] });
      } catch (error) {
        console.error(error);
        const embed = new EmbedBuilder()
          .setColor('#DC3545')
          .setTitle("Error")
          .setDescription("❌ An error occurred while trying to unlock this channel.");

        message.reply({ embeds: [embed] });
      }
    } else {
      const embed = new EmbedBuilder()
        .setColor('#FFCC00')
        .setTitle("Channel Already Unlocked")
        .setDescription("🔒 This channel is already unlocked.");

      message.reply({ embeds: [embed] });
    }
  },
};
