const db = require('pro.db');
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: "warn",
  description: "Warn a member",
  options: [
    {
      name: 'user',
      type: 6,
      required: true,
      description: "Who is the user to warn?"
    },
    {
      name: 'reason',
      type: 3,
      required: true,
      description: "What is the reason?"
    }
  ],

  run: async (client, interaction, args) => {
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason');
    
    if (!interaction.guild.me.permissions.has('KICK_MEMBERS')) {
      return interaction.reply({ content: ":x: | I don't have `KICK_MEMBERS` permission", ephemeral: true });
    }
    
    if (!interaction.member.permissions.has('KICK_MEMBERS')) {
      return interaction.reply({ content: ":x: | You don't have `KICK_MEMBERS` permission", ephemeral: true });
    }

    const embed = new MessageEmbed()
      .setColor('GREEN')
      .setDescription(`**Successfully warned ${member.user.username} :white_check_mark:**`);

    const userEmbed = new MessageEmbed()
      .setColor('YELLOW')
      .setTitle(':warning: You have been warned')
      .setDescription(`**You have been warned in ${interaction.guild.name}** for \`${reason}\``)
      .setFooter(`By ${interaction.user.tag}`);

    try {
      db.add(`warns_${interaction.guild.id}_${member.id}`, 1);
      await member.send({ embeds: [userEmbed] });
      await interaction.reply({ embeds: [embed] });
    } catch (err) {
      console.log(err);
      interaction.reply({ content: ":x: | An error occurred while sending the warning.", ephemeral: true });
    }
  }
};
