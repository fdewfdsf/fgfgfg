const figlet = require("figlet");

module.exports = {
  name: "draw",
  description: "Draws the input text in ASCII art",
  options: [
    {
      name: "text",
      description: "The text to draw in ASCII art",
      type: "STRING",
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const text = interaction.options.getString("text");

    try {
      const asciiArt = await generateFigletText(text);
      interaction.reply(`\`\`\`${asciiArt}\`\`\``);
    } catch (error) {
      console.error("Error generating ASCII art:", error);
      interaction.reply({ content: "❌ Something went wrong while generating the ASCII art. Please try again later.", ephemeral: true });
    }
  },
};

function generateFigletText(text) {
  return new Promise((resolve, reject) => {
    figlet(text, (err, data) => {
      if (err) {
        reject(new Error("Failed to generate ASCII art"));
      } else {
        resolve(data);
      }
    });
  });
}
