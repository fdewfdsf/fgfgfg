module.exports = {
  name: 'set-ai-chat',
  description: 'Set the chat GPT channel',
  options: [
    {
      name: 'channel',
      description: 'The AI channel',
      type: 'CHANNEL',
      required: true,
    },
  ],

  run(client, interaction, args) {
    const db = require('pro.db');
    const { Permissions } = require('discord.js');

    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.reply("**You don't have the necessary permissions to use this command.**");
    }

    const channel = interaction.options.getChannel('channel') || interaction.channel;
    db.set(`chatgpt-ch${interaction.guild.id}`, channel.id);

    interaction.reply("Channel set Chat GPT on " + channel);
  },
};
