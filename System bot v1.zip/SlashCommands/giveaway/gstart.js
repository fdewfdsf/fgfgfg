const { Permissions, MessageEmbed } = require("discord.js");
const humanizeDuration = require("humanize-duration");
const fs = require('fs');
const path = require('path');


module.exports = {
  name: "gstart",
  description: "Start a giveaway",
  options: [
    {
      name: "prize",
      type: "STRING",
      description: "The prize of the giveaway",
      required: true,
    },
    {
      name: "time",
      type: "STRING",
      description: "The duration of the giveaway",
      required: true,
    },
    {
      name: "winners",
      type: "INTEGER",
      description: "The number of winners for the giveaway",
      required: true,
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.reply({ content: "You don't have permission to use this command.", ephemeral: true });
    }

    const prize = interaction.options.getString("prize");
    const duration = interaction.options.getString("time");
    const winners = interaction.options.getInteger("winners");
    const host = interaction.user;
    const serverLanguage = getServerLanguage(interaction.guild.id);

    const preEmbedText = `🎉 ***Giveaway Started*** 🎉`;

    const embed = new MessageEmbed()
      .setTitle(prize)
      .setDescription(`**Ends In:** \`${humanizeDuration(parseTime(duration), { round: true })}\` \n**Winners:** ${winners}\n**Hosted by:** ${host}`)
      .setColor("BLUE")
      .setFooter("React with 🎉 to participate!");

    const message = await interaction.channel.send({ content: preEmbedText, embeds: [embed] });
    message.react("🎉");

    let timeLeft = parseTime(duration);
    let timeInterval;

    function updateMessage() {
      timeLeft -= 1000;
      if (timeLeft <= 0) {
        clearInterval(timeInterval);
        return;
      }

      const updatedEmbed = new MessageEmbed(embed)
        .setDescription(`**Ends In:** \`${humanizeDuration(timeLeft, { round: true })}\` \n**Winners:** ${winners}\n**Hosted by:** ${host}`);

      message.edit({ content: preEmbedText, embeds: [updatedEmbed] });
    }

    timeInterval = setInterval(updateMessage, 1000);

    setTimeout(async () => {
      clearInterval(timeInterval);

      const users = await message.reactions.cache.get("🎉").users.fetch();
      const entries = users.filter((user) => !user.bot);

      if (entries.size < winners) {
        return interaction.channel.send("**Not enough participants to determine a winner!**")
          .then((msg) => msg.delete({ timeout: 5000 }));
      }

      const winnersArray = [];
      const winnerEntries = entries.random(winners);
      winnerEntries.forEach((user) => winnersArray.push(`**<@${user.id}>**`));

      interaction.channel.send(`🎉 ***Congratulations ${winnersArray.join(", ")}! You won ${prize}!*** 🎉`);
    }, timeLeft);
  },
};

function parseTime(time) {
  const regex = /(\d+)([smhdw])/;
  const matches = time.match(regex);
  if (!matches) {
    throw new Error("Invalid time format.");
  }

  const amount = parseInt(matches[1]);
  const unit = matches[2];

  switch (unit) {
    case "s":
      return amount * 1000;
    case "m":
      return amount * 60 * 1000;
    case "h":
      return amount * 60 * 60 * 1000;
    case "d":
      return amount * 24 * 60 * 60 * 1000;
    case "w":
      return amount * 7 * 24 * 60 * 60 * 1000;
    default:
      throw new Error("Invalid time unit.");
  }
}


