const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');
const ytdl = require('ytdl-core');
const search = require('yt-search');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } = require('@discordjs/voice');
const express = require('express');
const queue = new Map();

module.exports = {
    name: 'play',
    description: 'Plays a song in the voice channel.',
    options: [
        {
            name: 'song',
            description: 'The song to play or search for (YouTube URL or search query).',
            type: 'STRING',
            required: true,
        },
    ],
    async run(client, interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            const noVoiceChannelEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**You need to be in a voice channel to play music.**');
            return interaction.reply({ embeds: [noVoiceChannelEmbed] });
        }

        try {
            let connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: interaction.guild.id,
                adapterCreator: interaction.guild.voiceAdapterCreator,
            });

            if (!connection) {
                connection = joinVoiceChannel({
                    channelId: voiceChannel.id,
                    guildId: interaction.guild.id,
                    adapterCreator: interaction.guild.voiceAdapterCreator,
                });
            }

            await interaction.deferReply();

            const query = interaction.options.getString('song');

            let songInfo;
            if (ytdl.validateURL(query)) {
                songInfo = await ytdl.getInfo(query);
            } else {
                const { videos } = await search(query);
                if (!videos.length) {
                    const notFoundEmbed = new MessageEmbed()
                        .setColor('RED')
                        .setDescription('**No search results found.**');
                    return interaction.followUp({ embeds: [notFoundEmbed] });
                }
                songInfo = await ytdl.getInfo(videos[0].url);
            }

            const song = {
                title: songInfo.videoDetails.title,
                url: songInfo.videoDetails.video_url,
                thumbnail: songInfo.videoDetails.thumbnails[0].url,
            };

            const serverQueue = queue.get(interaction.guild.id);

            if (!serverQueue) {
                const queueConstruct = {
                    textChannel: interaction.channel,
                    voiceChannel: voiceChannel,
                    connection: connection,
                    songs: [],
                    player: createAudioPlayer(),
                };

                queue.set(interaction.guild.id, queueConstruct);
                queueConstruct.songs.push(song);

                const stream = ytdl(song.url, { filter: 'audioonly' });
                const resource = createAudioResource(stream);

                queueConstruct.player.play(resource);
                connection.subscribe(queueConstruct.player);

                const playEmbed = new MessageEmbed()
                    .setColor('BLUE')
                    .setTitle(song.title)
                    .setURL(song.url)
                    .setThumbnail(song.thumbnail)
                    .setDescription(`**Now playing: [${song.title}](${song.url})**`);

                const row = new MessageActionRow()
                    .addComponents(
                        new MessageButton()
                            .setCustomId('stop')
                            .setLabel('Stop')
                            .setStyle('DANGER')
                    );

                interaction.followUp({ embeds: [playEmbed], components: [row] });

                queueConstruct.player.on(AudioPlayerStatus.Idle, () => {
                    queueConstruct.songs.shift();
                    if (queueConstruct.songs.length > 0) {
                        const nextSong = queueConstruct.songs[0];
                        const stream = ytdl(nextSong.url, { filter: 'audioonly' });
                        const resource = createAudioResource(stream);
                        queueConstruct.player.play(resource);
                    } else {
                        setTimeout(() => {
                            if (connection.state.status === AudioPlayerStatus.Idle) {
                                connection.destroy();
                                queue.delete(interaction.guild.id);
                            }
                        }, 3600000);
                    }
                });

                queueConstruct.player.on('error', error => {
                    console.error(error);
                    const errorEmbed = new MessageEmbed()
                        .setColor('RED')
                        .setDescription('**An error occurred while trying to play the song.**');
                    interaction.followUp({ embeds: [errorEmbed] });
                    connection.destroy();
                    queue.delete(interaction.guild.id);
                });
            } else {
                if (connection) {
                    serverQueue.songs.push(song);
                    const addedToQueueEmbed = new MessageEmbed()
                     .setColor('BLUE')
                    .setTitle(song.title)
                    .setURL(song.url)
                    .setThumbnail(song.thumbnail)
                    .setDescription(`**Now Queue: [${song.title}](${song.url})**`);
                    interaction.followUp({ embeds: [addedToQueueEmbed] });

                    const nextSong = serverQueue.songs[0];
                    const stream = ytdl(nextSong.url, { filter: 'audioonly' });
                    const resource = createAudioResource(stream);
                    serverQueue.player.play(resource);
                } else {
                    connection = joinVoiceChannel({
                        channelId: voiceChannel.id,
                        guildId: interaction.guild.id,
                        adapterCreator: interaction.guild.voiceAdapterCreator,
                    });

                    const queueConstruct = {
                        textChannel: interaction.channel,
                        voiceChannel: voiceChannel,
                        connection: connection,
                        songs: [],
                        player: createAudioPlayer(),
                    };

                    queue.set(interaction.guild.id, queueConstruct);
                    queueConstruct.songs.push(song);

                    const stream = ytdl(song.url, { filter: 'audioonly' });
                    const resource = createAudioResource(stream);

                    queueConstruct.player.play(resource);
                    connection.subscribe(queueConstruct.player);

                    const playEmbed = new MessageEmbed()
                        .setColor('BLUE')
                        .setTitle(song.title)
                        .setURL(song.url)
                        .setThumbnail(song.thumbnail)
                        .setDescription(`**Now playing: [${song.title}](${song.url})**`);

                    const row = new MessageActionRow()
                        .addComponents(
                            new MessageButton()
                                .setCustomId('stop')
                                .setLabel('Stop')
                                .setStyle('DANGER')
                        );

                    interaction.followUp({ embeds: [playEmbed], components: [row] });

                    queueConstruct.player.on(AudioPlayerStatus.Idle, () => {
                        queueConstruct.songs.shift();
                        if (queueConstruct.songs.length > 0) {
                            const nextSong = queueConstruct.songs[0];
                            const stream = ytdl(nextSong.url, { filter: 'audioonly' });
                            const resource = createAudioResource(stream);
                            queueConstruct.player.play(resource);
                        } else {
                            setTimeout(() => {
                                if (connection.state.status === AudioPlayerStatus.Idle) {
                                    connection.destroy();
                                    queue.delete(interaction.guild.id);
                                }
                            }, 3600000);
                        }
                    });

                    queueConstruct.player.on('error', error => {
                        console.error(error);
                        const errorEmbed = new MessageEmbed()
                            .setColor('RED')
                            .setDescription('**An error occurred while trying to play the song.**');
                        interaction.followUp({ embeds: [errorEmbed] });
                        connection.destroy();
                        queue.delete(interaction.guild.id);
                    });
                }
            }
        } catch (error) {
            console.error(error);
            const errorEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**An error occurred while trying to play the song.**');
            interaction.followUp({ embeds: [errorEmbed] });
        }
    },
};
