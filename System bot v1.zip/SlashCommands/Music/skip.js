const { MessageEmbed } = require('discord.js');
const { AudioPlayerStatus } = require('@discordjs/voice');
const queue = new Map();

module.exports = {
    name: 'skip',
    description: 'Skips the current song.',
    async run(client, interaction) {
        const serverQueue = queue.get(interaction.guild.id);
        if (!serverQueue || !serverQueue.player || serverQueue.player.state.status !== AudioPlayerStatus.Playing) {
            const noSongPlayingEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**There is no song playing that I could skip.**');
            return interaction.reply({ embeds: [noSongPlayingEmbed] });
        }

        serverQueue.player.stop();

        const skipEmbed = new MessageEmbed()
            .setColor('BLUE')
            .setDescription('**Skipped the current song.**');
        interaction.reply({ embeds: [skipEmbed] });
    },
};
