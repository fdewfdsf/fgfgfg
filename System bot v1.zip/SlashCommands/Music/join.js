const { joinVoiceChannel } = require('@discordjs/voice');
const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'join',
    description: 'Joins the voice channel.',
    async run(client, interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            const noVoiceChannelEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**You need to be in a voice channel for me to join.**');
            return interaction.reply({ embeds: [noVoiceChannelEmbed] });
        }

        const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
        if (!permissions.has('CONNECT') || !permissions.has('SPEAK')) {
            const noPermissionsEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**I don\'t have permissions to join or speak in that voice channel.**');
            return interaction.reply({ embeds: [noPermissionsEmbed] });
        }

        joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: interaction.guild.id,
            adapterCreator: interaction.guild.voiceAdapterCreator,
        });

        const joinedEmbed = new MessageEmbed()
            .setColor('BLUE')
            .setDescription(`**Joined the voice channel: ${voiceChannel.name}**`);
        interaction.reply({ embeds: [joinedEmbed] });
    },
};
