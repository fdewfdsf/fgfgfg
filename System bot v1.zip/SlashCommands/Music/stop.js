const { MessageEmbed } = require('discord.js');
const { getVoiceConnection, AudioPlayerStatus } = require('@discordjs/voice');

module.exports = {
    name: 'stop',
    description: 'Stops the music and removes the bot from the voice channel.',
    async run(client, interaction) {
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel) {
            const noVoiceChannelEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**You need to be in a voice channel to stop the music.**');
            return interaction.reply({ embeds: [noVoiceChannelEmbed] });
        }

        const permissions = voiceChannel.permissionsFor(interaction.guild.me);
        if (!permissions.has('CONNECT') || !permissions.has('SPEAK')) {
            const noPermissionsEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**I don\'t have permissions to join or speak in that voice channel.**');
            return interaction.reply({ embeds: [noPermissionsEmbed] });
        }

        const connection = getVoiceConnection(interaction.guild.id);
        if (!connection) {
            const noConnectionEmbed = new MessageEmbed()
                .setColor('RED')
                .setDescription('**I am not connected to any voice channel.**');
            return interaction.reply({ embeds: [noConnectionEmbed] });
        }

        const player = connection.state.subscription.player;

        player.stop(true);

        const serverQueue = client.queue.get(interaction.guild.id);
        if (serverQueue) {
            serverQueue.songs = [];
        }

        connection.destroy();

        const stoppedEmbed = new MessageEmbed()
            .setColor('BLUE')
            .setDescription('**Music stopped. The bot has left the voice channel.**');
        interaction.reply({ embeds: [stoppedEmbed] });
    },
};
