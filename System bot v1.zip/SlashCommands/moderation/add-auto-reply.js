const db = require("pro.db");
const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "add-auto-reply",
  description: "Set an auto-reply message",
  options: [
    {
      name: "trigger",
      description: "The trigger word or phrase",
      type: "STRING",
      required: true
    },
    {
      name: "response",
      description: "The auto-reply response",
      type: "STRING",
      required: true
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    await interaction.deferReply(); // تأجيل الرد

    const trigger = interaction.options.getString("trigger");
    const response = interaction.options.getString("response");

    if (!trigger || !response) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Missing Information")
        .setDescription("Please provide both trigger and response.");

      await interaction.followUp({ embeds: [embed], ephemeral: true });
      return;
    }

    const existingResponse = db.get(`auto-reply_${interaction.guildId}_${trigger}`);

    if (existingResponse) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Auto-reply Already Set")
        .setDescription("The trigger word or phrase is already associated with an auto-reply.");

      await interaction.followUp({ embeds: [embed], ephemeral: true });
      return;
    }

    db.set(`auto-reply_${interaction.guildId}_${trigger}`, response);

    const successEmbed = new MessageEmbed()
      .setColor("GREEN")
      .setDescription("Auto-reply set successfully.")
      .addField("Trigger", trigger)
      .addField("Response", response);

    interaction.followUp({ embeds: [successEmbed] });
  }
};
