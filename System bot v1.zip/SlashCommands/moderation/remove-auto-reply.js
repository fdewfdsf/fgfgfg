const db = require("pro.db");
const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "remove-auto-reply",
  description: "Remove an auto-reply message",
  options: [
    {
      name: "trigger",
      description: "The trigger word or phrase",
      type: "STRING",
      required: true
    }
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const trigger = interaction.options.getString("trigger");

    const existingResponse = db.get(`auto-reply_${interaction.guild.id}_${trigger}`);
    if (!existingResponse) {
      const errorEmbed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Auto-Reply Not Found")
        .setDescription("The specified auto-reply does not exist.");

      interaction.reply({ embeds: [errorEmbed] });
      return;
    }

    db.delete(`auto-reply_${interaction.guild.id}_${trigger}`);

    const successEmbed = new MessageEmbed()
      .setDescription("Auto-reply removed successfully.")
      .addField("Trigger", trigger);

    interaction.reply({ embeds: [successEmbed] });
  }
};
