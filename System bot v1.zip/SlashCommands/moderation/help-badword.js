const { MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "help-badwords",
  description: "Display commands related to bad words",
  run: async (client, message) => {
    const embed = new MessageEmbed()
      .setTitle("Bad Words Commands")
      .setDescription("Here are the commands related to bad words:")
      .addField("/add-bad-word <word>", "Add a bad word to the filter")
      .addField("/remove-bad-word <word>", "Remove a bad word from the filter")
      .addField("/check-bad-words <text>", "Check if a message contains bad words")
      .addField("/list-bad-words", "List all the bad words in the filter")
      .addField("/help-badwords", "To see all commands for bad words")
      .setColor("GREEN")
      .setThumbnail(client.user.displayAvatarURL());

    message.channel.send({ embeds: [embed] });
  },
};
