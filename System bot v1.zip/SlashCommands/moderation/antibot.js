const { MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "antibot",
  description: "Prevent any bot from entering the server.",
  options: [
    {
      name: "status",
      description: "Toggle antibot status.",
      type: "STRING",
      choices: [
        {
          name: "on",
          value: "on",
        },
        {
          name: "off",
          value: "off",
        },
      ],
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const guildId = interaction.guild.id;
    const status = interaction.options.getString("status");
if (interaction.user.id !== interaction.guild.ownerId) {
  return interaction.reply({
    content: "Only the server owner can use this command.",
    ephemeral: true,
  });
}


    
    if (status === "on") {
      db.set(`servers.${guildId}.botKickingStatus`, true);
      interaction.reply({ content: "antibot has been enabled.", ephemeral: true });
    } else if (status === "off") {
      db.set(`servers.${guildId}.botKickingStatus`, false);
      interaction.reply({ content: "antibot has been disabled.", ephemeral: true });
    }
  },
  registerEvents: (client) => {
    client.on("guildMemberAdd", (member) => {
      const guildId = member.guild.id;
      const botKickingStatus = db.get(`servers.${guildId}.botKickingStatus`);

      if (botKickingStatus && member.user.bot) {
        member.kick().catch((error) => {
          console.error(`Failed to kick bot ${member.user.tag}:`, error);
        });

        const serverOwner = member.guild.owner;
        const botName = member.user.tag;
        const serverName = member.guild.name;

        const embed = new MessageEmbed()
          .setColor("RED")
          .setTitle("Bot Kicking Alert")
          .setDescription(
            `A bot was kicked from the server:\n\nBot: ${botName}\nServer: ${serverName}`
          );

        serverOwner.send({ embeds: [embed] }).catch((error) => {
          console.error(
            `Failed to send message to server owner ${serverOwner.user.tag}:`,
            error
          );
        });
      }
    });
  },
};
