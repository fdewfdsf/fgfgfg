const { Permissions, MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "list-auto-reply",
  description: "List all the auto-reply words",
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.channel.send("You don't have permission to use this command.");
    }

    const autoReply = db.get(`auto-reply_${interaction.guild.id}`) || [];

    if (autoReply.length === 0) {
      return interaction.reply("**__Updating Soon...__**");
    }

    const embed = new MessageEmbed()
      .setColor("#FF0000")
      .setTitle("List of auto-reply :")
      .setDescription(autoReply.join("\n"));

    interaction.reply({ embeds: [embed] });
  },
};
