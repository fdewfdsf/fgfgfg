const { MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "check-bad-words",
  description: "Check if a message contains bad words",
  options: [
    {
      name: "text",
      type: "STRING",
      description: "The text to check for bad words",
      required: true,
    },
  ],
  run: async (client, interaction) => {
    const text = interaction.options.getString("text");

    const badWords = db.get(`bad_words_${interaction.guild.id}`) || [];
    const foundBadWords = badWords.filter((word) => text.toLowerCase().includes(word.toLowerCase()));

    const embed = new MessageEmbed();

    if (foundBadWords.length > 0) {
      embed.setColor("RED");
      embed.setDescription("The text contains inappropriate content.");
    } else {
      embed.setColor("GREEN");
      embed.setDescription("The text does not contain any bad words.");
    }

    await interaction.reply({ embeds: [embed] });
  },
};
