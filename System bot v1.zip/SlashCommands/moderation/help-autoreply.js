const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "help-auto-reply",
  description: "Show help for managing auto replies",
  run: async (client, interaction) => {
    const embed = new MessageEmbed()
      .setColor("GREEN")
      .setTitle("Auto-Reply Commands")
      .setDescription("/Here are the available commands for managing auto replies:")
      .addFields(
        { name: "/add-auto-reply", value: "Add a new auto reply trigger and response." },
        { name: "/remove-auto-reply", value: "Remove an existing auto reply trigger." },
        { name: "/help-autoreply", value: "To see the auto reply command." },
        { name: "/list-auto-reply", value: "List all auto reply triggers." }
      );

    await interaction.reply({ embeds: [embed] });
  }
};
