const { Permissions, MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "remove-bad-word",
  description: "Remove a bad word from the filter",
  options: [
    {
      name: "word",
      type: "STRING",
      description: "The bad word to remove",
      required: true,
    },
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.channel.send("You don't have permission to use this command.");
    }

    const word = interaction.options.getString("word");

    const guildId = interaction.guild.id;
    const badWords = db.get(`bad_words_${guildId}`) || [];

    if (!badWords.includes(word)) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setDescription(`The word "${word}" is not found in the bad word filter.`);

      return interaction.reply({ embeds: [embed] });
    }

    const updatedWords = badWords.filter((w) => w !== word);
    db.set(`bad_words_${guildId}`, updatedWords);

    const embed = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`The word "${word}" has been removed from the bad word filter.`);

    await interaction.reply({ embeds: [embed] });
  },
};
