const { Permissions, MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "add-bad-word",
  description: "Add a bad word to the filter",
  options: [
    {
      name: "word",
      type: "STRING",
      description: "The bad word to add",
      required: true,
    },
  ],
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.channel.send("You don't have permission to use this command.");
    }

    const word = interaction.options.getString("word");

    const guildId = interaction.guild.id;
    const badWords = db.get(`bad_words_${guildId}`) || [];

    if (badWords.includes(word)) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setDescription(`The word "${word}" is already added to the bad word filter.`);

      return interaction.reply({ embeds: [embed] });
    }

    badWords.push(word);
    db.set(`bad_words_${guildId}`, badWords);

    const embed = new MessageEmbed()
      .setColor("GREEN")
      .setDescription(`The word "${word}" has been added to the bad word filter.`);

    await interaction.reply({ embeds: [embed] });
  },
};
