const { Permissions, MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "list-bad-words",
  description: "List all the bad words",
  run: async (client, interaction) => {
    if (!interaction.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
      return interaction.channel.send("You don't have permission to use this command.");
    }

    const badWords = db.get(`bad_words_${interaction.guild.id}`) || [];

    if (badWords.length === 0) {
      return interaction.reply("No bad words have been added.");
    }

    const embed = new MessageEmbed()
      .setColor("#FF0000")
      .setTitle("List of Bad Words")
      .setDescription(badWords.join("\n"));

    interaction.reply({ embeds: [embed] });
  },
};
