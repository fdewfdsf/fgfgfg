const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "help-line",
  description: "See line commands",
  run: async (client, message) => {
    const embed = new MessageEmbed()
      .setColor("GREEN")
      .setTitle("Help: Line Commands")
      .setDescription("Here are the commands related to the line feature:")
      .addField("/set-line", "Sets a line image for the server.")
      .addField("/line", "Displays the set line image.")
      .addField("/add-auto-line [channel]", "Adds an auto line for a specified channel.")
      .addField("/remove-auto-line [channel]", "Removes the auto line from a specified channel.")
      .addField("/list-auto-line", "Lists all channels with auto lines set.")
      .addField("/help-line", "Displays the available commands related to the line feature.");

    message.reply({ embeds: [embed] });
  }
};
