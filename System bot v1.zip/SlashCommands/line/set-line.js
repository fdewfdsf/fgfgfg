const { MessageEmbed } = require("discord.js");
const db = require("pro.db");
const urlRegex = require("url-regex");

module.exports = {
  name: "set-line",
  description: "Set the line image",
  options: [
    {
      name: "line",
      description: "The URL of the line image",
      type: "STRING",
      required: true
    }
  ],
  run(client, interaction) {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      return interaction.reply({ ephemeral: true, embeds: [new MessageEmbed().setDescription("You don't have permission to use this command.")] });
    }

    const line = interaction.options.getString("line");
    const regex = /https:\/\/media\.discordapp\.net\/attachments\/.*\/.*\/.*/;
    if (!urlRegex({exact: true}).test(line) && !regex.test(line)) {
      return interaction.reply({ ephemeral: true, embeds: [new MessageEmbed().setDescription("Please provide a valid image URL.")] });
    }

    db.set(`line_${interaction.guild.id}`, line);

    const successEmbed = new MessageEmbed()
      .setDescription("Line set successfully.")
      .setImage(line);

    interaction.reply({ embeds: [successEmbed] });
  }
};
