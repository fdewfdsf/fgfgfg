const db = require("pro.db");
const { MessageEmbed } = require("discord.js");

module.exports = {
  name: "line",
  description: "Get the line image",

  run: async (client, interaction) => {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("Permission Denied")
        .setDescription("You don't have permission to use this command.");

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const line = db.get(`line_${interaction.guild.id}`);
    if (!line) {
      const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("No Line Set")
        .setDescription("No line has been set.");

      await interaction.reply({ embeds: [embed], ephemeral: true });
      return;
    }

    const channel = interaction.channel;
    const webhooks = await channel.fetchWebhooks();

    if (webhooks.size > 0) {
      const oldWebhook = webhooks.first();
      await oldWebhook.delete();
    }

    const webhook = await channel.createWebhook(interaction.guild.name, {
      avatar: interaction.guild.iconURL()
    });

    const payload = {
      files: [line]
    };

    await webhook.send(payload);
    await webhook.delete();

    await interaction.delete();
  }
};

                            