const { MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "list-auto-line",
  description: "List the channels added to the auto line storage",
  run(client, message) {
    const storedChannels = db.get(`auto_lines_${message.guild.id}`) || [];

    if (storedChannels.length === 0) {
      const emptyEmbed = new MessageEmbed()
        .setTitle("Auto Line Storage")
        .setDescription("The auto line storage is empty.")
        .setColor("GREEN");

      return message.reply({ embeds: [emptyEmbed] });
    }

    const channels = storedChannels
      .map((channelID) => message.guild.channels.cache.get(channelID))
      .filter((channel) => channel && channel.type === "GUILD_TEXT");

    if (channels.length === 0) {
      const invalidEmbed = new MessageEmbed()
        .setTitle("Auto Line Storage")
        .setDescription("No valid channels found in the auto line storage.")
        .setColor("GREEN");

      return message.reply({ embeds: [invalidEmbed] });
    }

    const embed = new MessageEmbed()
      .setTitle("Auto Line Storage")
      .setDescription(
        channels.map((channel) => `<#${channel.id}>`).join("\n")
      )
      .setColor("GREEN");

    message.reply({ embeds: [embed] });
  }
};
