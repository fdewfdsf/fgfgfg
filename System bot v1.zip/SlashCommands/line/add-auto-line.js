const { MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "add-auto-line",
  description: "Add channels to the auto line storage",
  options: [
    {
      name: "channel",
      description: "The channel to add to the auto line storage",
      type: "CHANNEL",
      required: true,
      channelTypes: ["GUILD_TEXT"]
    }
  ],
  async run(client, interaction) {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      return interaction.reply({ ephemeral: true, content: "You don't have permission to use this command." });
    }

    const channel = interaction.options.get("channel").channel;

    const line = db.get(`line_${interaction.guild.id}`);

    if (!line) {
      return interaction.reply({ ephemeral: true, content: "The line has not been set yet, use `/set-line` to set the line." });
    }

    const storedChannels = db.get(`auto_lines_${interaction.guild.id}`) || [];
    const newChannels = [...new Set([...storedChannels, channel.id])];

    db.set(`auto_lines_${interaction.guild.id}`, newChannels);

    const embed = new MessageEmbed()
      .setDescription(`Channel <#${channel.id}> has been added to the auto line storage.`)
      .setColor("GREEN");

    interaction.reply({ embeds: [embed] });

    const sendWebhook = async (channelID) => {
      const channel = await client.channels.fetch(channelID);

      if (channel && channel.isText()) {
        const server = interaction.guild;
        const webhook = await channel.createWebhook(server.name, {
          avatar: server.iconURL({ dynamic: true }),
        });

        // قم بتحديد خط واحد هنا
        const singleLine = line.split('\n')[0];

        await webhook.send(singleLine);
        await webhook.delete();
      }
    };

    client.on("messageCreate", (message) => {
      if (newChannels.includes(message.channel.id) && !message.author.bot) {
        sendWebhook(message.channel.id);
      }
    });
  },
};
