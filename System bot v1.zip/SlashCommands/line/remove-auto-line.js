const { MessageEmbed } = require("discord.js");
const db = require("pro.db");

module.exports = {
  name: "remove-auto-line",
  description: "Remove a channel from the auto line storage",
  options: [
    {
      name: "channel",
      description: "The channel to remove from the auto line storage",
      type: "CHANNEL",
      required: false,
      channelTypes: ["GUILD_TEXT"]
    }
  ],
  run(client, interaction) {
    if (!interaction.member.permissions.has("ADMINISTRATOR")) {
      return interaction.reply({ ephemeral: true, content: "You don't have permission to use this command." });
    }

    const guildID = interaction.guild.id;
    const storedChannels = db.get(`auto_lines_${guildID}`) || [];

    if (storedChannels.length === 0) {
      return interaction.reply({ ephemeral: true, content: "The auto line storage is empty." });
    }

    if (!interaction.options.get("channel")) {
      const selectableChannels = storedChannels
        .map((channelID) => interaction.guild.channels.cache.get(channelID))
        .filter((channel) => channel && channel.type === "GUILD_TEXT");

      if (selectableChannels.length === 0) {
        return interaction.reply({ ephemeral: true, content: "No valid channels found in the auto line storage." });
      }

      const embed = new MessageEmbed()
        .setTitle("Selectable Channels")
        .setDescription(
          selectableChannels
            .map((channel, index) => `${index + 1}. <#${channel.id}>`)
            .join("\n")
        )
        .setColor("#00ff00");

      return interaction.reply({ embeds: [embed] });
    }

    const channel = interaction.options.get("channel").channel;

    if (!storedChannels.includes(channel.id)) {
      return interaction.reply({ ephemeral: true, content: "The specified channel is not in the auto line storage." });
    }

    const newChannels = storedChannels.filter((channelID) => channelID !== channel.id);

    db.set(`auto_lines_${guildID}`, newChannels);

    const successEmbed = new MessageEmbed()
      .setDescription(`The channel <#${channel.id}> has been removed from the auto line storage.`)
      .setColor("#00ff00");

    interaction.reply({ embeds: [successEmbed] });
  }
};
